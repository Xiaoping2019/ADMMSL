function [euf,et0,k] = NSTD_ADMM(Sp,rm,Q)
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
M=size(rm,2);
lama=rand(2,M);
rho=0.1;
u=rand(2,M);
x=rand(2,1);
for k=1:5000
for i=1:M
    u(:,i)=x-Sp(:,i)+1/rho*lama(:,i);
    alpha(:,i)=u(:,i)/norm(u(:,i));
end
G=zeros(M+1,M+1);
h=zeros(M+1,1);
for i=1:M
   G(i,i)=1+0.5*rho;G(i,M+1)=1;
   G(M+1,i)=1;
   G(M+1,M+1)=M;
   h(i)=rm(i)+0.5*rho*norm(u(:,i));
   h(M+1)=sum(rm);
end
ey=inv(G)*h;
g=ey(1:M);
%%
for i=1:M
      pp(:,i)=Sp(:,i)+g(i)*alpha(:,i)-1/rho*lama(:,i);
end
x2=x;
x=mean(pp')';
 tol=norm(x-x2)/min(norm(x),norm(x2));
if tol<1e-15
    break;
end
%%
for i=1:M
    lama(:,i)=lama(:,i)+rho*(x-Sp(:,i)-g(i)*alpha(:,i));
end
 end
euf=x;
et0=ey(M+1);
end

