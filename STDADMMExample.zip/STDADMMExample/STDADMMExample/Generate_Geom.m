function [geom] = Generate_Geom(N,M,range)
% This program generates the preliminary solution for Efficient ADMM Solutions for TOA-based Localization of Asynchronous Sources.  
% The code works for 2-D.  Please refer to the following paper for the details.
%% Xiaoping Wu et al., Efficient ADMM Solutions for TOA-based Localization of Asynchronous Sources
% Submitted to IEEE Communication Letters, 

%
% Input Parameter List:
% N:        N is the number of geomtry configurations.
% M:        M is the number of sensors.
% range     the least range between sensors.
%
% Output Parameter List:
% geom:    cell{N,1}  sensor positions of N geomtry configurations. 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Xiaoping Wu     4-28-2025
%
%       Copyright (C) 2025
%       School of Information Engineering
%       Huzhou University
%       Huzhou, 311300, China.
%       wuxipu@gmail.com
geom=cell(N,1);
flag=zeros(N*100,1);
k=0;
for gg=1:N*100
    Sp=2*rand(2,M)-1;   %% produce N geometry configuration according to the uniform distribution [-1,1]
        for j = 1:M
        Diff = repmat(Sp(:, j), 1, M) - Sp(:, :);  
        Dist_i2All = sqrt(diag(Diff'*Diff));
        Dist_Mat(j, :) = Dist_i2All; % distance matrix
        end
       for i = 1:M
         for j=1:M
          if ((Dist_Mat(i,j)<range) && (Dist_Mat(i,j)>0)) % if distance<range, delete the configuration
              flag(gg)=1;
          end
       end
       end
   if (flag(gg)==0 && k<N)
       k=k+1;
       geom{k}=Sp;
     end
end
end