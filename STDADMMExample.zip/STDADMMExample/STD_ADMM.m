function [est_u,est_t0] = STD_ADMM(s,rm,Q)
% This program generates the preliminary solution for Efficient ADMM Solutions for TOA-based Localization of Asynchronous Sources.  
% The code works for 2-D.  Please refer to the following paper for the details.
%% Xiaoping Wu et al., Efficient ADMM Solutions for TOA-based Localization of Asynchronous Sources
% Submitted to IEEE Communication Letters, 

%
% Input Parameter List:
% s:        2xM, sensor positions, M is the number of sensors.
% rm:       1xM, distance measurements.
% Q:        MxM, covariance matrix of distance measurements.
%
% Output Parameter List:
% est_u:    2x1,  source position estimate. 
% est_t0:   1, transmission time. 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Xiaoping Wu     4-28-2025
%
%       Copyright (C) 2025
%       School of Information Engineering
%       Huzhou University
%       Huzhou, 311300, China.
%       wuxipu@gmail.com

M=size(rm,2);
lambda=rand(2,M);
v=rand(2,M);
z=rand(2,1);
p=rand(2,M);
psi=zeros(M+1,1);
for i=1:M
 psi(i)=norm(p(:,i));
end
psi(M+1)=rand(1,1);
C=zeros(M+1,M+1);
d=zeros(M+1,1);
d0=[rm sum(rm)]';
tol=1;
for k=1:10000
  %% find rho to ensure the convexity
for i=1:M
tt=psi(M+1);
rhom(i)=2*(rm(i)-tt-norm(p(:,i)))/norm(p(:,i));
end
rho=max(max(rhom),0)+0.1;
%% updating x
v=kron(ones(1,M),z)-s+1/rho*lambda;
for i=1:M
   vn(i)= norm(v(:,i));
   alpha(:,i)=v(:,i)/vn(i);
end
d=d0+0.5*rho*[vn 0]';
iC=[2/(2+rho)*eye(M)+4/(rho*M*(2+rho))*ones(M,1)*ones(1,M) -2/(rho*M)*ones(M,1);-2/(rho*M)*ones(1,M) (2+rho)/(rho*M)];
psi=iC*d;
p=psi(1:M)'.*alpha;
%% updating z
zt=s+p-1/rho*lambda;
z2=z;
z=mean(zt')';
%% stopping criterion
tol=norm(z-z2)/min(norm(z),norm(z2));
if tol<1e-15
    break;
end
%% updating lambda
lambda=lambda+rho*(kron(ones(1,M),z)-s-p);
 end
est_u=z;  %% obtaining the estimates
est_t0=psi(M+1);
end