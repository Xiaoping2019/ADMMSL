% This is the main program for ��Efficient ADMM Solutions for TOA-based Localization of Asynchronous Sources�� 
% It works for 2-D case. 
%
% This program will reproduce results (when setting G=20, L=500 in the code) 
% for Figs. 1 of 
% Xiaoping Wu et al., Efficient ADMM Solutions for TOA-based Localization of Asynchronous Sources
% Submitted to IEEE Communication Letters, 
%%%%%%%%%%%%%%%%%%%%%%%%%%% function description %%%%%%%%%%%%%%%%%%%%%%%%%%
% STD_ADMM.m:                    STD_ADMM solution
% UTT_CRLB.m:                    CRLB 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Xiaoping Wu     4-28-2025
%
%       Copyright (C) 2025
%       School of Information Engineering
%       Huzhou University
%       Huzhou, 311300, China.
%       wuxipu@gmail.com
clear all;
warning off;
M=5;   % number of sensors;
Uf=[0.2 -0.1]'; % position of source, the unit is km
N=20; %  N=20 is the number of random geometry configurations of sensors 
range=0.3; % the least distance between sensors
geom = Generate_Geom(N,M,range);
t0=rand(1,1)+2; % the transmission time
MC =500;     % number of ensemble runs
nseTmp = zeros(M,MC); % noise matrix
for m = 1:MC
    nseTmp(:,m) = randn(M,1);% produce the Gaussion noise randomly
end
nseTmp = nseTmp - mean(nseTmp,2);  % the Gaussian noise with zero-mean
for st=1:7
sigma= 10^((st-9)/2)   % noise is varied from 0.1 m to 100 m
Q=sigma^2*eye(M); % noise covariance
ss=0;
for gf=1:N
  Sp=geom{gf};  
 for i=1:M
     rm0(i)=norm(Uf-Sp(:,i))+t0;  % generate the true measurements
end
for sf=1:MC
    ss=ss+1;
rm=rm0+sigma*nseTmp(:,sf)'; % generate the noisy measurements
[admm_estu,admm_estt0] = STD_ADMM(Sp,rm,Q);
[nadmm_estu,nadmm_estt0] = NSTD_ADMM(Sp,rm,Q);

 admm_seu(ss)=norm(admm_estu-Uf)^2;  % squared error of source position
 nadmm_seu(ss)=norm(nadmm_estu-Uf)^2;  
 admm_set0(ss)=norm(admm_estt0-t0)^2; % squared error of transmission time
 nadmm_set0(ss)=norm(nadmm_estt0-t0)^2;
 admmb_estu(ss,:)=admm_estu; % recording the estimtes for bias calculation
 nadmmb_estu(ss,:)=nadmm_estu; 
 [Crlbu,Crlbt] = UTT_CRLB(Sp,Uf,Q);
 Cruf(ss,:)=Crlbu;
 Crtf(ss,:)=Crlbt;
end
end
admm_rmseu(st)=sqrt(mean(admm_seu))*10^3  % rmse of source position
nadmm_rmseu(st)=sqrt(mean(nadmm_seu))*10^3
crlbu(st)=sqrt(mean(Cruf))*10^3  % CRLB of source position
admm_rmset(st)=sqrt(mean(admm_set0))*10^3   % rmse of transmission time
nadmm_rmset(st)=sqrt(mean(nadmm_set0))*10^3
crlbt(st)=sqrt(mean(Crtf))*10^3  % CRLB of transmission time
admm_biasu(st)=norm(mean(admmb_estu)'-Uf)*10^3  % Bias of source position
nadmm_biasu(st)=norm(mean(nadmmb_estu)'-Uf)*10^3
end


